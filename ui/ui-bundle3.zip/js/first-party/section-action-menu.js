(function(){
var _$sectionActionMenuBundle_1 = {};
;(function () {
	'use strict';

	// A helper function to build one menu item
	function addMenuItem(headerElem, menu, icon, action, subaction, details, callback) {
		const item = document.createElement('div');
		item.innerHTML = [
			`<span class="menu-icon ${icon}"></span>`,
			`<span class="menu-action">${action}</span>`,
			`<span class="menu-subaction">${subaction}</span>`,
			`<span class="menu-details">${details}</span>`
		].join('');

		item.className = 'menu-item';
		item.onclick = (evt) => {
			callback();
			headerElem.classList.remove('menu-active');
		};

		menu.appendChild(item);
	}

	function changeRequestTemplate(pageTitle, headerTitle, srcPath, anchorName) {
		const pageLink = `[${pageTitle}](${srcPath})`;
		const sectionName = `${headerTitle}, \`${anchorName}\``;

		const pageWidth = Math.max(4, pageLink.length);
		const sectionWidth = Math.max(7, sectionName.length);

		// We could add a "title" key here in addition to "description" if we wanted to pre-populate the title
		return {
			description: [
				/* eslint-disable max-len */
				'<!--',
				'Instructions for the Submitter',
				'1. Add a title for you change request in the box above',
				'2. Choose the appropriate Severity and Nature by editing the label names',
				'     Severity Choices:',
				'       Minor    -- a nuisance; we won’t fuss if it is not fixed our way',
				'       Major    -- a serious problem that must be fixed; we are proposing a solution but are ready to compromise',
				'       Critical -- a show stopper; we will vote against publication of the document unless this is changed the way we want it',
				'',
				'     Nature Choices:',
				'       Editorial -- when changing only text without changing content; can be applied by the editors without discussion',
				'       Technical -- when changing anything in the technical content',
				'',
				'3. Add specific text changes that should be applied to the document',
				'   A Change Request must include unambiguous identification of the precise text or illustration, where the change is needed, and quoted text if required.',
				'',
				'   It should include explicit instructions using keywords to make the change unambiguous; i.e., add, create, change, delete, move, merge, rename, replace, restore, update.',
				'   For example, change from: existing text to: new proposal, or insert words before existing text, or delete the second sentence.',
				'',
				'   There may be cases where a reviewer feels they are unable to provide text; for example, where a clarification is requested. In such cases there are two options:',
				'   * Write down one of the possible alternatives; this at least serves to illustrate the concern',
				'   * Contact someone else, in advance, who may be able to suggest some wording, before submitting a Change Request',
				'',
				'4. Add rationale for the change, explaining why it is an improvement',
				'   A Change Request must include the reason that the change is needed; the reason that suggested change is preferred over other possibilities, etc.',
				'   This is the opportunity to persuade other reviewers to support the Change Request.',
				'-->',
				'',
				'# Relevant Portion of the Document',
				'',
				`| ${'Page'.padEnd(pageWidth)} | ${'Section'.padEnd(sectionWidth)} |`,
				`|-${'-'.repeat(pageWidth)}-|-${'-'.repeat(sectionWidth)}-|`,
				`| ${pageLink.padEnd(pageWidth)} | ${sectionName.padEnd(sectionWidth)} |`,
				'',
				'# Specific Changes',
				'',
				'<!-- This GitLab quick action adds labels to specify the Severity & Nature of the Change Request.',
				'     Keep the formatting in tact, including the quotes, and change the portion after the double colons.',
				'     Note this is case sensitive and should be Proper Case.',
				'     Us the "Preview" button near the top of the description box to check the formatting is correct.',
				'     It should have two "Adds ... Label" lines at the end that correspond with your label choices.',
				'',
				'     Alternatively, you can use the Labels dropdown below to add labels.',
				'-->',
				'/label ~"Severity::Minor"',
				'/label ~"Nature::Editorial"',
				'',
				'Add specific changes here...',
				'',
				'# Rationale',
				'',
				'Add rationale here...'
				/* eslint-enable max-len */
			].join('\n')
		};
	}

	// The main functionality must wait until the page loads, so we can replace the anchor elements
	window.addEventListener('load', async (evt) => {
		const page = window.antoraParams.page;
		const newIssueRoot = `${page.origin.webUrl}/-/issues/new`;

		// The anchors were created by Antora to copy the HTML Links
		// We will replace them with a custom menu
		const anchors = document.body.querySelectorAll('article.doc .anchor');

		for (const anchor of anchors) {
			const anchorHref = anchor.getAttribute('href');
			const headerElem = anchor.parentElement;
			const headerTitle = headerElem.innerText;

			const anchorUrl = window.location.href.split('#')[0] + anchorHref;
			const antoraXRef = [
				'xref:',
				page.version, '@',
				page.component.name, ':',
				page.module, ':',
				page.relativeSrcPath,
				anchorHref,
				'[]'
			].join('');

			const changeRequest = changeRequestTemplate(
				page.title,
				headerTitle,
				`modules/${page.module}/pages/${page.relativeSrcPath}`,
				anchorHref.split('#').pop());

			const encodedCR = Object.keys(changeRequest)
				.map((key) => `issue[${key}]=${encodeURIComponent(changeRequest[key])}`)
				.join('&');

			const newIssueHref = `${newIssueRoot}?${encodedCR}`;

			// --------------------

			const menuContainer = document.createElement('div');
			menuContainer.className = 'section-action-menu-container';

			const span = document.createElement('span');
			span.className = 'section-action-menu-button fa-solid fa-ellipsis-vertical';

			const menu = document.createElement('div');
			menu.className = 'section-action-menu';

			menuContainer.appendChild(span);
			menuContainer.appendChild(menu);

			addMenuItem(headerElem, menu,
				'fa-solid fa-link', 'HTML Link', 'Copy to Clipboard', anchorUrl,
				() => {
					navigator.clipboard.writeText(anchorUrl);
					window.showToast('Copied HTML Link to Clipboard');
				});

			addMenuItem(headerElem, menu,
				'fa-solid fa-pen-to-square', 'Antora XRef', 'Copy to Clipboard', antoraXRef,
				() => {
					navigator.clipboard.writeText(antoraXRef);
					window.showToast('Copied Antora XRef to Clipboard');
				});

			// The presumption is that if the page isn't directly editable, there's probably no
			// good way to send a user to an issue creation board, either
			if (page.editUrl) {
				addMenuItem(headerElem, menu,
					'fa-brands fa-gitlab', 'Change Request', 'Open in New Tab', newIssueRoot,
					() => window.open(newIssueHref, '_blank'));
			}

			// Clicking on the vertical ellipsis opens the menu
			span.onclick = function (evt) {
				evt.stopPropagation = true;
				headerElem.classList.toggle('menu-active');
			};

			anchor.replaceWith(menuContainer);
		}

		// Clicking anywhere on the page closes all menus
		document.body.addEventListener('click', (evt) => {
			for (const activeMenu of document.body.querySelectorAll('.menu-active')) {
				if (! activeMenu.contains(evt.target))
					activeMenu.classList.remove('menu-active');
			}
		});
	});
})();

}());
