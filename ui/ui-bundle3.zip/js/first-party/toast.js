(function(){
var _$toastBundle_1 = {};
;(function () {
	'use strict';

	window.addEventListener('load', async (evt) => {
		const toaster = document.createElement('div');
		toaster.className = 'toaster';

		const toast = document.createElement('span');
		toast.className = 'toast';

		toaster.appendChild(toast);
		document.body.appendChild(toaster);

		let timer;

		// A simple utility function. Call window.showToast("Message") and your message
		// will be displayed for 2 seconds. Second calls before the first one closes will
		// change the message, then reset the timer for another 2 seconds
		window.showToast = function (msg) {
			toast.innerHTML = msg;
			toaster.classList.add('show');

			if (timer) window.clearTimeout(timer);
			timer = window.setTimeout(() => toaster.classList.remove('show'), 2000);
		};
	});
})();

}());
