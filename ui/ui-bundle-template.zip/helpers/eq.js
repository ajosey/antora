'use strict'

module.exports = (a, b) => a === b
